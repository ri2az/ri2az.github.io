![Moustache et cinéma](/images/avatar.png)

# Moustache et cinema

Un petit site de recos cinéma avec des fichiers texte en quelques dizaines de lignes de code.
